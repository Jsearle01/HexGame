package com.searle.hexgame.desktop;


import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;
import com.badlogic.gdx.graphics.Color;
import com.searle.hexgame.HexGame;


public class DesktopLauncher {
	
	public static Color color = new Color();
	
	public static void main (String[] arg) {
		LwjglApplicationConfiguration config = new LwjglApplicationConfiguration();
		config.title = "HexGame";
		//config.resizable = false;
		config.height = 480;
		config.width = 640;
		config.initialBackgroundColor = color;
		
		new LwjglApplication(new HexGame(), config);
	}
}
