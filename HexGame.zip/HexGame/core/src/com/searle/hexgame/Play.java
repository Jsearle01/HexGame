package com.searle.hexgame;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.maps.MapProperties;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.HexagonalTiledMapRenderer;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.viewport.ExtendViewport;


public class Play implements Screen {

	private TiledMap map;
	private HexagonalTiledMapRenderer renderer;
	private OrthographicCamera camera;
	private int viewheight = 480;
	private int viewwidth = 640;
	private float camerazoom= (float) 1.5f;
	public GameCursor cursor;
	private TextureAtlas CursorAtlas;
	private ExtendViewport viewport;
	
	
	public void render(float delta){
		Gdx.gl.glClearColor(0,0,0,1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		camera.position.set((Gdx.graphics.getWidth()/2+30), (Gdx.graphics.getHeight()/2+30), 0);
		float BBH = camera.viewportHeight; 
		float BBW = camera.viewportWidth;
		Update();
		System.out.println(BBW);
		System.out.println(BBH);
		String position1 = camera.position.toString();
		System.out.println(position1);
		
		System.out.println(cursor.getX());
		System.out.println(cursor.getY());
		
		camera.update();
		renderer.setView(camera);
		renderer.render();
		
		//SpriteBatch Rendering Start
		renderer.getBatch().begin();
		
		cursor.draw(renderer.getBatch());
		renderer.getBatch().setProjectionMatrix(camera.combined);
		renderer.getBatch().end();
		//SpriteBatch Rendering End
		}
	
	public void Update(){
	if(Gdx.input.isKeyPressed(Keys.A)){
		cursor.setX(cursor.getX() -(20 * Gdx.graphics.getDeltaTime()));
		if(cursor.getX() <= 0)
			cursor.setX(0);
	}
	
	if (Gdx.input.isKeyPressed(Keys.D)){
		cursor.setX(cursor.getX() +(20 * Gdx.graphics.getDeltaTime()));
		if(cursor.getX() >= (640))
			cursor.setX(640);
	}
	
	if(Gdx.input.isKeyPressed(Keys.W)){
		cursor.setY(cursor.getY() +(20 * Gdx.graphics.getDeltaTime()));
		if(cursor.getY() >= 480)
			cursor.setY(480);
	}
	if(Gdx.input.isKeyPressed(Keys.S)){
		cursor.setY(cursor.getY() -(20 * Gdx.graphics.getDeltaTime()));
		if(cursor.getY() <= 0)
			cursor.setY(0);
	}
	
	}
	
	public void show() {
		map = new TmxMapLoader().load("maps/hexmap1.tmx");
		renderer = new HexagonalTiledMapRenderer(map);
		camera = new OrthographicCamera();
		cursor = new GameCursor(new Sprite(new Texture("Sprites/Cursor.png")));
		//Gdx.input.setInputProcessor(cursor);
		
		
		
	}
	
	public void dispose() {
		map.dispose();
		renderer.dispose();
		cursor.getTexture().dispose();
		cursor.dispose();
		
	}
	
	
	
	@Override
	public void pause() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void resume() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void hide() {
		// TODO Auto-generated method stub
		
	}
	public void resize(int width, int height) {

		camera.viewportWidth = viewwidth;
		camera.viewportHeight = viewheight;
		camera.zoom = camerazoom;// TODO Auto-generated method stub
		//viewport = new ExtendViewport(640,480,camera);
		
	}

	
}
	