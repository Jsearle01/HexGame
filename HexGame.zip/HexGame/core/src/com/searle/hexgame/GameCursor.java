package com.searle.hexgame;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.math.Vector2;

import javafx.scene.Cursor;

public class GameCursor extends Sprite implements InputProcessor {
	
	
	private TiledMapTileLayer SelectionLayer;
	private Vector2 cursortile = new Vector2();
	
	private Vector2 cursormovement = new Vector2();
	
	
	public GameCursor (Sprite sprite){
		super(sprite);
		
		
	}
	public void create(){
		
	}
	
	
	public void draw(SpriteBatch Spritebatch){
		Update(Gdx.graphics.getDeltaTime());
		
		super.draw(Spritebatch);
		
		
	}
	
	
		
	public void Update(float delta){
		
		
			
		}
		
	


	public void dispose() {
		// TODO Auto-generated method stub
	}

	

	

	@Override
	public boolean keyDown(int keycode) {
		switch(keycode){
		case Keys.A:
			cursormovement.x = (-100);
			break;
		case Keys.W:
			// Player tile.y += 1;
			break;
		case Keys.S:
			// Player tile.y -= 1;
			break;
		case Keys.D:
			cursormovement.x = (100);
			
		}
		return true;
	}

	@Override
	public boolean keyUp(int keycode) {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean keyTyped(char character) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean touchDown(int screenX, int screenY, int pointer, int button) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean touchUp(int screenX, int screenY, int pointer, int button) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean touchDragged(int screenX, int screenY, int pointer) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean mouseMoved(int screenX, int screenY) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean scrolled(int amount) {
		// TODO Auto-generated method stub
		return false;
	}


	public Vector2 getCursortile() {
		return cursortile;
	}


	public void setCursortile(Vector2 cursortile) {
		this.cursortile = cursortile;
		
	}


	


	
	

}
