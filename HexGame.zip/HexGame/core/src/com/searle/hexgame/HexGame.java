package com.searle.hexgame;


import com.badlogic.gdx.Game;



public class HexGame extends Game {
	
	@Override
	public void create () {
		setScreen(new Play());
		
	
	}
	
	@Override
	public void pause() {
		// TODO Auto-generated method stub
		super.pause();
	}
	@Override
	public void resume() {
		// TODO Auto-generated method stub
		super.resume();
	}
	//batch = new SpriteBatch();
		//img = new Texture("badlogic.jpg");
	@Override
	public void render () {
		super.render();
		
		
	}
	
	@Override
	public void dispose () {
		super.dispose();
		
	}
}
